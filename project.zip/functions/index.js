const {onDocumentCreated}=require('firebase-functions/v2/firestore');const admin=require('firebase-admin');admin.initializeApp();
exports.notify=onDocumentCreated('chats/{c}/msgs/{m}',async e=>{
  const m=e.data.data(),db=admin.firestore(),c=(await db.doc('chats/'+e.params.c).get()).data(),s=(await db.doc('users/'+m.from).get()).data(),tokens=[];
  for(const u of c.members.filter(x=>x!=m.from)){const d=(await db.doc('users/'+u).get()).data();tokens.push(...(d.tokens||[]))}
  if(!tokens.length)return;
  await admin.messaging().sendEachForMulticast({tokens,notification:{title:c.group?c.name:s.name,body:(c.group?s.name+': ':'')+(m.text||'['+m.type+']')}});
});
