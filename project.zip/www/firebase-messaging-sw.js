importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js','https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js');
firebase.initializeApp({/* PASTE THE SAME FIREBASE WEB CONFIG HERE */});
firebase.messaging();
