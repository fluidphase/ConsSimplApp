importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js','https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js');
firebase.initializeApp({apiKey:"AIzaSyAbaKvXYuFS8HikfGYoz_MTOSBGw052TtU",authDomain:"constellate-cool.firebaseapp.com",projectId:"constellate-cool",storageBucket:"constellate-cool.firebasestorage.app",messagingSenderId:"865952808925",appId:"1:865952808925:web:f6c0cc55bfcbbba8144034",measurementId:"G-LY8NC89BTY"});
firebase.messaging();
