# Constellate
1. console.firebase.google.com → new project → add Web app → copy config into www/index.html (const cfg).
2. Enable Authentication (Email/Password) and Firestore. Storage is not needed (images are stored in Firestore, no video yet).
3. Paste firestore.rules into the Firestore Rules tab.
4. Test: serve www/ (npx serve www) or open on any static host.
5. Push this folder to a GitHub repo → Actions → "Build Android APK" → download Constellate-apk artifact.

## Push notifications
1. Firebase console > Project settings > Cloud Messaging: generate a Web Push key and put it in `VAPID` in www/index.html. Paste the web config into www/firebase-messaging-sw.js too.
2. Upgrade to the Blaze plan, then `npm i -g firebase-tools && firebase login && firebase init functions` (keep existing files) and `firebase deploy --only functions`.
3. Android: Project settings > add an Android app with id app.constellate.chat, download google-services.json, then in GitHub repo Settings > Secrets > Actions add GOOGLE_SERVICES_JSON containing the file's full text.
